import os

print("Starting ETL Pipeline...")

os.system("python scripts/extract.py")
os.system("python scripts/transform.py")
os.system("python scripts/load.py")

print("ETL Pipeline Completed Successfully!")
