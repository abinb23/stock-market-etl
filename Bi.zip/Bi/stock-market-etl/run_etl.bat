@echo off
cd /d D:\Coding\Bi\stock-market-etl

call venv\Scripts\activate.bat

python main.py