import requests
import json
import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("FMP_API_KEY")

symbol = "AAPL"

url = f"https://financialmodelingprep.com/stable/historical-price-eod/full?symbol={symbol}&apikey={API_KEY}"

response = requests.get(url)

data = response.json()

os.makedirs("data/raw", exist_ok=True)

with open("data/raw/stock_data.json", "w") as file:
    json.dump(data, file, indent=4)

print("Stock data saved successfully!")
print(type(data))
print(data[:2])
    