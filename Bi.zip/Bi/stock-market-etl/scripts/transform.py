import json
import pandas as pd
import os

with open("data/raw/stock_data.json", "r") as file:
    data = json.load(file)

df = pd.DataFrame(data)

df = df[["symbol", "date", "open", "high", "low", "close", "volume"]]

df.drop_duplicates(inplace=True)
df.dropna(inplace=True)

df["date"] = pd.to_datetime(df["date"])
df["open"] = pd.to_numeric(df["open"])
df["high"] = pd.to_numeric(df["high"])
df["low"] = pd.to_numeric(df["low"])
df["close"] = pd.to_numeric(df["close"])
df["volume"] = pd.to_numeric(df["volume"])

os.makedirs("data/processed", exist_ok=True)

df.to_csv("data/processed/cleaned_stock_data.csv", index=False)

print("Data transformed successfully!")
print(df.head())
